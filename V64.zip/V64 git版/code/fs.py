import sys
import os

# 合并工程文件夹
current_dir = os.path.dirname(os.path.abspath(__file__))
state_dir = os.path.join(current_dir, 'state')
sys.path.append(state_dir)
