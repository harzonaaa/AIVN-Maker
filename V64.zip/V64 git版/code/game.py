import pygame
from fs import *
from main_game import MainGame
from main_menu import MainMenu
from main_hist import MainHist
from main_conf import MainConf
from main_save import MainSave

class Game:
    def __init__(self):
        self.running = True
        self.states = {          'main_menu': MainMenu(self),
                                 'main_game': MainGame(self),
                                 'main_hist': MainHist(self),
                                 'main_conf': MainConf(self),
                                 'main_save': MainSave(self)}
        self.state = self.states['main_menu']
    def change_state(self, state_name): self.state = self.states[state_name]
    def run(self):
        while self.running:






 





            self.state.process()
















        pygame.quit()
if __name__ == "__main__":
    Game().run()