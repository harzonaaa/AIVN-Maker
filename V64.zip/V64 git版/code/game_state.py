from pgini import *
class GameState:
    def __init__(self, game):
        self.game = game
        self.screen, self.oss, self.iss = pgini("宅男的人间冒险", "../src/gui/logo.png", (1024, 768), (1024, 768))