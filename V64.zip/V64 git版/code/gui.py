import time
import pygame
import textwrap
import hashlib
import os
import cv2
import numpy as np
from moviepy.editor import VideoFileClip

class VideoPlayer():
    def __init__(self, screen, surface):
        self.screen = screen
        self.surface = surface
        self.video_cap = None
        self.video_path = None
        self.audio_played = False

    def generate_temp_audio_path(self, video_path):
        # 生成基于视频路径的唯一哈希值
        video_path_hash = hashlib.md5(video_path.encode('utf-8')).hexdigest()
        temp_audio_path = f"src/temp_audio_{video_path_hash}.wav"
        return temp_audio_path

    def play_audio_from_video(self, video_path):
        temp_audio_path = self.generate_temp_audio_path(video_path)
        
        # 检查是否需要播放音频
        if not self.audio_played or self.video_path != video_path:
            if not os.path.exists(temp_audio_path):  # 避免重复生成
                video = VideoFileClip(video_path)
                video.audio.write_audiofile(temp_audio_path, codec='pcm_s16le')
            
            pygame.mixer.music.load(temp_audio_path)
            pygame.mixer.music.play()
            self.audio_played = True
            self.video_path = video_path  # 更新当前视频路径

    def play_video_frame(self):
        if self.video_cap is not None and self.video_cap.isOpened():
            ret, frame = self.video_cap.read()
            if ret:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                frame = pygame.surfarray.make_surface(np.transpose(frame, (1, 0, 2)))
                self.surface.blit(frame, (0, 0))
            else:
                # 视频播放结束，可能需要重置视频或做其他处理
                self.video_cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                self.reset_video_and_audio()

    def reset_video_and_audio(self):
        if self.video_cap is not None:
            self.video_cap.release()
            self.video_cap = None
        self.audio_played = False
        pygame.mixer.music.stop()




class Slider:
    def __init__(self, x, y, w, h, min_val, max_val, initial_val, color, handle_color, info, font):
        self.x, self.y, self.width, self.height, self.min, self.max, self.value, self.color, self.handle_color, self.dragging, self.info, self.font = x, y, w, h, min_val, max_val, initial_val, color, handle_color, False, info, font

    def draw(self, screen):
        pygame.draw.rect(screen, self.color, (self.x, self.y, self.width, self.height))
        handle_x = ((self.value - self.min) / (self.max - self.min)) * (self.width - self.height) + self.x
        pygame.draw.rect(screen, self.handle_color, (handle_x, self.y, self.height, self.height))
        text = self.font.render(self.info, True, (255, 255, 255))
        screen.blit(text, (self.x, self.y - text.get_height() - 10))

    def handle_event(self, event, scale_x, scale_y):
        if event.type == pygame.MOUSEBUTTONDOWN:
            scaled_mouse_x, scaled_mouse_y = event.pos[0] / scale_x, event.pos[1] / scale_y
            if self.y < scaled_mouse_y < self.y + self.height:  self.dragging = True
        elif event.type == pygame.MOUSEBUTTONUP:                self.dragging = False
        elif event.type == pygame.MOUSEMOTION and self.dragging:
            scaled_mouse_x = event.pos[0] / scale_x
            rel_x = scaled_mouse_x - self.x
            rel_x = max(0, min(self.width, rel_x))
            self.value = (rel_x / self.width) * (self.max - self.min) + self.min


class Button:
    def __init__(self, x, y, text_color, hover_color, text, font):
        self.x, self.y, self.text, self.text_color, self.hover_color, self.current_color, self.font = x, y, text, text_color, hover_color, text_color, font

    def draw(self, screen, mouse_pos, scale_x, scale_y):
        text = self.font.render(self.text, True, self.current_color)
        screen.blit(text, (self.x, self.y))
        if self.is_over(mouse_pos, scale_x, scale_y):       self.current_color = self.hover_color
        else:                                               self.current_color = self.text_color

    def is_over(self, pos, scale_x, scale_y):
        scaled_pos = (pos[0] / scale_x, pos[1] / scale_y)
        temp = self.font.render(self.text, True, (0,0,0))
        text_width, text_height = temp.get_width(), temp.get_height()
        if self.x < scaled_pos[0] < self.x + text_width and self.y < scaled_pos[1] < self.y + text_height:
            return True
        return False







class HistoryViewer:
    def __init__(self, font, script, history):
        self.font = font
        self.script = script
        self.history = history
        self.scroll_offset = 0  # 用于滚动历史对话

    def draw(self, surface):
        # 绘制背景
        bg_color = (0, 0, 0, 128)  # 半透明黑色
        surface.fill(bg_color)

        # 从最近的对话开始，逆序渲染历史记录
        start_y = 1080 - 50  # 从底部开始绘制
        for index in reversed(self.history):
            dialogue = self.script[index].get("text", "")  # 获取对话文本
            text_surface = self.font.render(dialogue, True, (255, 255, 255))
            surface.blit(text_surface, (50, start_y + self.scroll_offset))
            start_y -= text_surface.get_height() + 10  # 更新下一个对话的绘制位置

            # 如果对话已经超出屏幕顶部，则不再绘制更多
            if start_y + self.scroll_offset < 0:
                break

    # 添加一个方法来更新滚动偏移量，比如响应鼠标滚轮或键盘输入
    def scroll(self, amount):
        self.scroll_offset += amount
        # 添加限制以防止过度滚动



        







class MenuButton:
    def __init__(self, x, y, text_color, hover_color, text, font):
        self.x, self.y, self.text, self.text_color, self.hover_color, self.current_color, self.font = x, y, text, text_color, hover_color, text_color, font

    def draw(self, screen):
        text = self.font.render(self.text, True, self.current_color)
        screen.blit(text, (self.x, self.y))

    def is_over(self, pos, scale_x, scale_y):
        scaled_pos = (pos[0] / scale_x, pos[1] / scale_y)
        temp = self.font.render(self.text, True, (0,0,0))
        text_width, text_height = temp.get_width(), temp.get_height()
        if self.x < scaled_pos[0] < self.x + text_width and self.y < scaled_pos[1] < self.y + text_height:
            return True
        return False

    def update(self, mouse_pos, scale_x, scale_y):
        if self.is_over(mouse_pos, scale_x, scale_y):       self.current_color = self.hover_color
        else:                                               self.current_color = self.text_color


class Menu:
    def __init__(self, options_data, font, start_x, start_y, button_height):
        self.buttons = []
        self.jump_points = options_data['jump']  # 存储跳转点
        print(self.jump_points)
        y_offset = start_y
        for index, label in enumerate(options_data['label']):  # 修改这里
            button = MenuButton(start_x, y_offset, (255, 255, 255), (100, 100, 100), label, font)  # 确保label是字符串
            self.buttons.append(button)
            y_offset += button_height + 10  # 为每个按钮添加垂直间距
            
    def draw(self, screen):
        for button in self.buttons:
            button.draw(screen)

    def update(self, mouse_pos, scale_x, scale_y):
        for button in self.buttons:
            button.update(mouse_pos, scale_x, scale_y)

    def is_over(self, mouse_pos, scale_x, scale_y):
        for i, button in enumerate(self.buttons):


            # 在这里设置各个按钮干什么即可
            if button.is_over(mouse_pos, scale_x, scale_y):
                print(self.jump_points[i])
                return self.jump_points[i]  # 返回对应的跳转点
        
        return None
    























class TextTyper:
    def __init__(self):
        self.text = ""
        self.displayed_text = ""
        self.speed = 10
        self.index = 0
        self.next_time = time.time()
        self.max_width = None

    def set_text(self, text, speed, max_width):
        self.text = text
        self.displayed_text = ""
        self.speed = speed
        self.index = 0
        self.next_time = time.time()
        self.max_width = max_width

    def draw(self, screen, font, pos, color, immi):
        if immi:                            self.displayed_text = self.text
        else:
            current_time = time.time()
            interval = 1 / self.speed
            if current_time >= self.next_time and self.index < len(self.text):
                self.displayed_text += self.text[self.index]
                self.index += 1
                self.next_time = current_time + interval

        wrapped_text = textwrap.wrap(self.displayed_text, width=self.max_width)
        x, y = pos
        for line in wrapped_text:
            rendered_text = font.render(line, True, color)
            screen.blit(rendered_text, (x, y))
            y += font.get_height()  # 更新y坐标以便在下一行绘制文本





















class Effects():
    @staticmethod
    def apply_dissolve_effect(prev_background, dissolve, dissolve_step, textbox_background, dissolve_finished, surface):
        if dissolve:
            alpha = max(0, min(255, dissolve_step * 5))
            if prev_background:
                prev_background.set_alpha(255 - alpha)
                surface.blit(prev_background, (0, 0))
            if textbox_background:
                textbox_background.set_alpha(alpha)
                surface.blit(textbox_background, (0, 0))
            dissolve_step += 1
            if alpha == 255:
                dissolve = False
                dissolve_finished = True  # 标记溶解效果完成
        return dissolve, dissolve_step, dissolve_finished

    @staticmethod
    def apply_fade_effect(surface, fade_in, alpha, max_alpha=255, fade_step=5):
        # 淡入淡出效果代码
        if fade_in:
            alpha += fade_step
        else:
            alpha -= fade_step
        alpha = max(0, min(alpha, max_alpha))
        surface.set_alpha(alpha)
        return alpha, alpha == max_alpha or alpha == 0

    @staticmethod
    def apply_blink_effect(surface, blink, blink_rate, blink_counter, max_counter=60):
        # 闪烁效果代码
        blink_counter += 1
        if blink_counter >= max_counter:
            blink_counter = 0
            blink = not blink
        surface.set_visible(blink)
        return blink, blink_counter

    @staticmethod
    def apply_move_effect(pos, target_pos, step):
        # 移动效果代码
        new_pos = (pos[0] + step if pos[0] < target_pos[0] else pos[0] - step,
                   pos[1] + step if pos[1] < target_pos[1] else pos[1] - step)
        # 确保不超过目标位置
        new_pos = (min(new_pos[0], target_pos[0]) if step > 0 else max(new_pos[0], target_pos[0]),
                   min(new_pos[1], target_pos[1]) if step > 0 else max(new_pos[1], target_pos[1]))
        finished = new_pos == target_pos
        return new_pos, finished



