import pygame
def pgini(name, ico, oss, iss):
    pygame.init()
    pygame.mixer.init()
    pygame.display.set_caption(name)
    pygame.display.set_icon(pygame.image.load(ico))
    screen = pygame.display.set_mode(iss, pygame.RESIZABLE)
    return screen, oss, iss