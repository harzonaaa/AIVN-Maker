import pygame
from game_state import GameState
from gui import *

class MainConf(GameState):
    def __init__(self, game):
        super().__init__(game)
        self.fullscreen = False
        self.last_window_size = (0,0)
        self.surface = pygame.Surface(self.oss)
        self.font = pygame.font.Font("../src/font/kai.ttf", 36)
 
        self.全屏 = Button(100, 100, (224, 224, 224), (129, 212, 250), "全屏", self.font)
        self.窗口 = Button(100, 200, (224, 224, 224), (129, 212, 250), "窗口", self.font)
        self.返回 = Button(100, 450, (224, 224, 224), (129, 212, 250), "返回", self.font)
        self.音量 = Slider(100, 350, 200, 20, 0, 1, 1, "#003D51", "#0099CC", "音量", self.font)

    def process(self):
        mouse_pos = pygame.mouse.get_pos()
        self.sw, self.sh = self.screen.get_size()
        scale_x = self.sw / self.oss[0]
        scale_y = self.sh / self.oss[1]
        events = pygame.event.get()
        for event in events:
            if event.type == pygame.QUIT:               self.game.running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:        self.game.change_state('main_menu')
                if event.key == pygame.K_F3:            self.game.change_state('main_game')
                if event.key == pygame.K_F11:
                    if self.fullscreen == False:
                        self.fullscreen = True
                        self.last_window_size = self.screen.get_size()
                        self.screen = pygame.display.set_mode(self.oss, pygame.FULLSCREEN)
                    elif self.fullscreen == True:
                        self.fullscreen = False
                        self.screen = pygame.display.set_mode(self.last_window_size, pygame.RESIZABLE)
            if event.type == pygame.MOUSEBUTTONDOWN:
                if self.全屏.is_over(mouse_pos, scale_x, scale_y):
                    if self.fullscreen == False:
                        self.fullscreen = True
                        self.last_window_size = self.screen.get_size()
                        self.screen = pygame.display.set_mode(self.oss, pygame.FULLSCREEN)
                if self.窗口.is_over(mouse_pos, scale_x, scale_y):
                    if self.fullscreen == True:
                        self.fullscreen = False
                        self.screen = pygame.display.set_mode(self.last_window_size, pygame.RESIZABLE)
            self.音量.handle_event(event, scale_x, scale_y)

        self.surface.fill((0, 0, 0))
        self.全屏.draw(self.surface, mouse_pos, scale_x, scale_y)
        self.窗口.draw(self.surface, mouse_pos, scale_x, scale_y)
        self.返回.draw(self.surface, mouse_pos, scale_x, scale_y)
        self.音量.draw(self.surface)
        pygame.mixer.music.set_volume(self.音量.value)
        scaled_surface = pygame.transform.scale(self.surface, (self.sw, self.sh))
        self.screen.blit(scaled_surface, (0, 0))
        pygame.display.flip()
        pygame.time.Clock().tick(144)


