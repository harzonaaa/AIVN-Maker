import pygame
from game_state import GameState
from main_game_script import *
from gui import *

class MainGame(GameState):
    def __init__(self, game):
        super().__init__(game)
        self.fullscreen = False
        self.last_window_size = (0,0)
        self.surface = pygame.Surface(self.oss)
        self.font = pygame.font.Font("../src/font/simhei.ttf", 30)

        # 位置
        self.tpos = (70, 620)           # 文字
        self.tbpos = (0, 545)           # 文字背景
        self.npos = (168, 545)          # 名字
        self.nbpos = (90, 510)          # 名字背景
        self.textbox = pygame.image.load('../src/gui/textbox.png')
        self.namebox = pygame.image.load('../src/gui/namebox.png')











        # 脚本和打印组
        self.script = script
        self.current_dialogue = 0
        self.previous_dialogue = -1
        self.typer = TextTyper()
        self.history = []

        # 视频播放组
        self.VideoPlayer = VideoPlayer(self.screen, self.surface)

        # 菜单组
        self.menu_active = False
        self.options = None

        # 转场组
        self.prev_background = None
        self.dissolve = False
        self.dissolve_step = 0
        self.textbox_background = None
        self.dissolve_finished = False

    def process(self):
        self.sw, self.sh = self.screen.get_size()
        scale_x = self.sw / self.oss[0]
        scale_y = self.sh / self.oss[1]
        mouse_pos = pygame.mouse.get_pos()
        events = pygame.event.get()
        for event in events:
            if event.type == pygame.QUIT:   self.game.running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.game.change_state('main_menu')                            
                if event.key == pygame.K_F1:
                    with open('../src/save/savegame.txt', 'w') as file: file.write(str(self.current_dialogue))
                if event.key == pygame.K_F2:
                    with open('../src/save/savegame.txt', 'r') as file: self.current_dialogue = int(file.read())
                if event.key == pygame.K_F3:
                    self.game.change_state('main_conf')
                if event.key == pygame.K_F4:
                    self.game.change_state('main_save')           
                if event.key == pygame.K_F5:
                    self.game.change_state('main_hist')           
                if event.key == pygame.K_F11:
                    if self.fullscreen == False:
                        self.fullscreen = True
                        self.last_window_size = self.screen.get_size()
                        self.screen = pygame.display.set_mode(self.oss, pygame.FULLSCREEN)
                    elif self.fullscreen == True:
                        self.fullscreen = False
                        self.screen = pygame.display.set_mode(self.last_window_size, pygame.RESIZABLE)

            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == pygame.BUTTON_LEFT:
                    self.history.append(self.current_dialogue)
                    if "next" in self.script[self.current_dialogue]:    self.current_dialogue += self.script[self.current_dialogue]["next"]
                    else:                                               self.current_dialogue += 1                       
                elif event.button == pygame.BUTTON_RIGHT:
                    if self.history:                                    self.current_dialogue = self.history.pop()

            if self.menu_active:
                self.option_menu.update(mouse_pos, scale_x, scale_y)
                if event.type == pygame.MOUSEBUTTONDOWN:
                    jump_point = self.option_menu.is_over(mouse_pos, scale_x, scale_y)
                    if jump_point is not None:
                        self.current_dialogue += jump_point
                        print(self.current_dialogue)

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LCTRL]:                                    self.current_dialogue += 10
        if keys[pygame.K_LSHIFT]:                                   self.current_dialogue -= 10

        # 确保current_dialogue的值在合理范围内, 然后再开始渲染
        self.current_dialogue = max(0, min(self.current_dialogue, len(self.script) - 1))

        # 这些不是每一帧都要做的事情，先做，保存这些事情
        if self.current_dialogue != self.previous_dialogue:

            # 背景变化检查和准备
            self.dissolve_finished = False
            if "ef" in self.script[self.current_dialogue] and not self.dissolve:
                self.dissolve = True
                self.dissolve_step = 0
                self.prev_background = self.surface.copy()
            else:
                self.dissolve_finished = True

            if "music" in self.script[self.current_dialogue]:                   # 音频刷新
                pygame.mixer.music.load(self.script[self.current_dialogue]["music"])
                pygame.mixer.music.play(-1)
            
            if "voice" in self.script[self.current_dialogue]:                   # 语音刷新
                pygame.mixer.stop()
                pygame.mixer.Sound(self.script[self.current_dialogue]["voice"]).play()

            if "bg" in self.script[self.current_dialogue]:
                bg = pygame.image.load(self.script[self.current_dialogue]["bg"])
                bg = pygame.transform.scale(bg, self.oss)
                self.surface.blit(bg, (0, 0))

            if "ci" in self.script[self.current_dialogue]:
                current_ci = pygame.image.load(self.script[self.current_dialogue]["ci"])
                self.surface.blit(current_ci, ((self.oss[0] - current_ci.get_rect().width) / 2, self.oss[1] - current_ci.get_rect().height))

            if "text" in self.script[self.current_dialogue]:
                self.surface.blit(self.textbox, self.tbpos)
                self.typer.set_text(self.script[self.current_dialogue]["text"], 144, 32)

            if "name" in self.script[self.current_dialogue]:
                self.surface.blit(self.namebox, self.nbpos)
                self.surface.blit(self.font.render(self.script[self.current_dialogue]["name"], True, (0, 0, 0)), self.npos)

            if "hi" in self.script[self.current_dialogue]:
                hi = pygame.image.load(self.script[self.current_dialogue]["hi"])
                self.surface.blit(hi, (-10, 680))

            self.previous_dialogue = self.current_dialogue
            self.textbox_background = self.surface.copy()
            self.VideoPlayer.video_path = None
        if "video" in self.script[self.current_dialogue]:
            video_path = self.script[self.current_dialogue]["video"]
            if self.VideoPlayer.video_path != video_path:
                self.VideoPlayer.reset_video_and_audio()
                self.VideoPlayer.video_path = video_path
                self.VideoPlayer.video_cap = cv2.VideoCapture(video_path)
                self.VideoPlayer.play_audio_from_video(video_path)
            self.VideoPlayer.play_video_frame()

        self.dissolve, self.dissolve_step, self.dissolve_finished = Effects.apply_dissolve_effect(self.prev_background, self.dissolve, self.dissolve_step, self.textbox_background, self.dissolve_finished, self.surface)

        if "label" in self.script[self.current_dialogue] and "jump" in self.script[self.current_dialogue]:
            if not self.menu_active:
                self.options = self.script[self.current_dialogue]
                self.option_menu = Menu(self.options, self.font, 1200, 500, 40)
                self.menu_active = True
        else:
            self.menu_active = False
            if "text" in self.script[self.current_dialogue]:
                if self.dissolve_finished:              self.typer.draw(self.surface, self.font, self.tpos, (0, 0, 0), False)
        if self.menu_active:                            self.option_menu.draw(self.surface)
        scaled_surface = pygame.transform.scale(self.surface, (self.sw, self.sh))
        self.screen.blit(scaled_surface, (0, 0))
        pygame.display.flip()
        pygame.time.Clock().tick(60)
