


image = "../src/image"
ci = "../src/image/ci"
bg = "../src/image/bg"
music = "../src/audio/music"




script = [



    {"name": "苏橙", "text": "我的名字叫做苏橙。", "music": f"{music}/Suddenly I See.mp3"},
    {"text": "我的名字叫做asdasd苏橙。"},
    {"text": "我的名字asdas叫做苏橙。"},
    {"text": "我的名字叫做苏sss橙。"},
    {"text": "我的名字叫做[character_name]。", "bg": f"{image}/b1.png"},
    {"text": "我的名字叫做[character_name]。", "bg": f"{image}/b1.png"},




]






if "bg" in script[0]:               last_bg_path = script[0]["bg"]
else:
    last_bg_path = "../src/gui/dbg.png"
    script[0]["bg"] = last_bg_path
for i in range(1, len(script)):
    if "bg" not in script[i]:       script[i]["bg"] = last_bg_path
    else:                           last_bg_path = script[i]["bg"]

if "ci" in script[0]:               last_ci_path = script[0]["ci"]
else:
    last_ci_path = "../src/gui/dbg.png"
    script[0]["ci"] = last_ci_path
for i in range(1, len(script)):
    if "ci" not in script[i]:       script[i]["ci"] = last_ci_path
    else:                           last_ci_path = script[i]["ci"]

if "hi" in script[0]:               last_hi_path = script[0]["hi"]
else:
    last_hi_path = "../src/gui/dbg.png"
    script[0]["hi"] = last_hi_path
for i in range(1, len(script)):
    if "hi" not in script[i]:       script[i]["hi"] = last_hi_path
    else:                           last_hi_path = script[i]["hi"]

if "ch" in script[0]:               last_ch_path = script[0]["ch"]
else:
    last_ch_path = ""
    script[0]["ch"] = last_ch_path
for i in range(1, len(script)):
    if "ch" not in script[i]:       script[i]["ch"] = last_ch_path
    else:                           last_ch_path = script[i]["ch"]
