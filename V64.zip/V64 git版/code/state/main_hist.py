import pygame
from game_state import GameState
from gui import *

class MainHist(GameState):
    def __init__(self, game):
        super().__init__(game)
        self.fullscreen = False
        self.last_window_size = (0,0)
        self.surface = pygame.Surface(self.oss)
        self.font = pygame.font.Font("../src/font/kai.ttf", 36)

    def process(self):
        self.sw, self.sh = self.screen.get_size()
        events = pygame.event.get()
        for event in events:
            if event.type == pygame.QUIT:                                       self.game.running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:                                self.game.change_state('main_menu')   
                if event.key == pygame.K_F5:                                    self.game.change_state('main_game')          
                if event.key == pygame.K_F11:
                    if self.fullscreen == False:
                        self.fullscreen = True
                        self.last_window_size = self.screen.get_size()
                        self.screen = pygame.display.set_mode(self.oss, pygame.FULLSCREEN)
                    elif self.fullscreen == True:
                        self.fullscreen = False
                        self.screen = pygame.display.set_mode(self.last_window_size, pygame.RESIZABLE)

        start_y = 100
        self.surface.fill("#5F777F")
        for index in self.game.states['main_game'].history[-10:]:
            script_entry = self.game.states['main_game'].script[index]
            if "text" in script_entry:
                text = self.game.states['main_game'].font.render(script_entry["text"], True, (255, 255, 255))
                self.surface.blit(text, (50, start_y))
                start_y += text.get_height() + 10  # 更新 Y 坐标，为下一条对话留出空间

        scaled_surface = pygame.transform.scale(self.surface, (self.sw, self.sh))
        self.screen.blit(scaled_surface, (0, 0))
        pygame.display.flip()
        pygame.time.Clock().tick(144)
