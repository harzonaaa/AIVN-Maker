import pygame
from game_state import GameState
from gui import *

class MainMenu(GameState):
    def __init__(self, game):
        super().__init__(game)
        self.fullscreen = False
        self.last_window_size = (0,0)
        self.surface = pygame.Surface(self.oss)
        self.font = pygame.font.Font("../src/font/kai.ttf", 36)
        self.bg = pygame.image.load("../src/gui/封面.jpg")

        self.开始 = Button(100, 100, "#C88490", (129, 212, 250), "开始", self.font)
        self.继续 = Button(100, 200, "#C88490", (129, 212, 250), "继续", self.font)
        self.存档 = Button(100, 300, "#C88490", (129, 212, 250), "存档", self.font)
        self.设置 = Button(100, 400, "#C88490", (129, 212, 250), "设置", self.font)
        self.退出 = Button(100, 500, "#C88490", (129, 212, 250), "退出", self.font)

    def process(self):
        mouse_pos = pygame.mouse.get_pos()
        self.sw, self.sh = self.screen.get_size()
        scale_x = self.sw / self.oss[0]
        scale_y = self.sh / self.oss[1]
        events = pygame.event.get()
        for event in events:
            if event.type == pygame.QUIT:                                       self.game.running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:                                self.game.change_state('main_menu')
                if event.key == pygame.K_F11:
                    if self.fullscreen == False:
                        self.fullscreen = True
                        self.last_window_size = self.screen.get_size()
                        self.screen = pygame.display.set_mode(self.oss, pygame.FULLSCREEN)
                    elif self.fullscreen == True:
                        self.fullscreen = False
                        self.screen = pygame.display.set_mode(self.last_window_size, pygame.RESIZABLE)
            if event.type == pygame.MOUSEBUTTONDOWN:
                if self.开始.is_over(mouse_pos, scale_x, scale_y):
                                                                                self.game.states['main_game'].current_dialogue = 0
                                                                                self.game.change_state('main_game')
                if self.设置.is_over(mouse_pos, scale_x, scale_y):              self.game.change_state('main_conf')
                if self.存档.is_over(mouse_pos, scale_x, scale_y):              self.game.change_state('main_save')
                if self.退出.is_over(mouse_pos, scale_x, scale_y):              self.game.running = False
                if self.继续.is_over(mouse_pos, scale_x, scale_y):
                                                                                self.game.change_state('main_game')
                                                                                with open('../src/save/savegame.txt', 'r') as file: self.game.states['main_game'].current_dialogue = int(file.read())

        self.surface.blit(pygame.transform.scale(self.bg, self.oss), (0, 0))
        self.开始.draw(self.surface, mouse_pos, scale_x, scale_y)
        self.继续.draw(self.surface, mouse_pos, scale_x, scale_y)
        self.存档.draw(self.surface, mouse_pos, scale_x, scale_y)
        self.设置.draw(self.surface, mouse_pos, scale_x, scale_y)
        self.退出.draw(self.surface, mouse_pos, scale_x, scale_y)
        scaled_surface = pygame.transform.scale(self.surface, (self.sw, self.sh))
        self.screen.blit(scaled_surface, (0, 0))
        pygame.display.flip()
        pygame.time.Clock().tick(144)
