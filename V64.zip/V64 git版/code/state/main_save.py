import os
import pygame
from game_state import GameState
from gui import *

class MainSave(GameState):
    def __init__(self, game):
        super().__init__(game)
        self.fullscreen = False
        self.last_window_size = (0,0)
        self.surface = pygame.Surface(self.oss)
        self.font = pygame.font.Font("../src/font/kai.ttf", 36)
        self.save_dir = '../src/save'  # 定义存档目录的相对路径

        # 初始化存档矩形
        self.slot_count = 6  # 更新为10个存档槽
        self.slots_per_row = 3  # 每行存档槽的数量
        self.start_x = 300
        # start_x = (self.oss[0] - (self.slot_width * self.slots_per_row + self.slot_margin * (self.slots_per_row - 1))) / 2  # 居中布局
        self.slot_width = 500  # 存档槽的宽度
        self.slot_height = int((self.slot_width / 16) * 9)  # 按16:9的比例计算高度
        self.slot_margin = 50  # 存档槽之间的间距
        self.slots = []
        for i in range(self.slot_count):
            row = i // self.slots_per_row  # 当前槽位所在行
            col = i % self.slots_per_row  # 当前槽位所在列，然后按照这个找左上角的点
            x = self.start_x + col * (self.slot_width + self.slot_margin)
            y = 200 + row * (self.slot_height + self.slot_margin)
            self.slots.append(pygame.Rect(x, y, self.slot_width, self.slot_height))

    def same_game(self, slot):
        if not os.path.exists(self.save_dir):       os.makedirs(self.save_dir)                          # 检查和生成文件叫
        filename = os.path.join(self.save_dir, f'savegame_{slot}.txt')                                  # 生成保存文件
        with open(filename, 'w') as file:           file.write(str(self.game.states['main_game'].current_dialogue))        
        screenshot_filename = os.path.join(self.save_dir, f'savegame_screenshot_{slot}.png')            # 生成保存截图
        pygame.image.save(pygame.display.get_surface(), screenshot_filename)
        
    def load_game(self, slot):
        filename = os.path.join(self.save_dir, f'savegame_{slot}.txt')
        try:
            with open(filename, 'r') as file:
                current_dialogue = int(file.read())
            print(f"Game loaded from {filename}")
            return current_dialogue
        except FileNotFoundError:
            print(f"No save found for slot {slot}")
            return None

    def draw(self):
        for i, slot in enumerate(self.slots):
            pygame.draw.rect(self.surface, (200, 200, 200), slot)  

            filename = os.path.join(self.save_dir, f'savegame_{i+1}.txt')
            if os.path.exists(filename):
                with open(filename, 'r') as file:
                    dialogue_number = file.readline().strip()
                text_surface = self.font.render(dialogue_number, True, (0, 0, 0))
                self.surface.blit(text_surface, (slot.x + (slot.width - text_surface.get_width()) / 2, slot.y + slot.height + 10))
                
            screenshot_filename = os.path.join(self.save_dir, f'savegame_screenshot_{i+1}.png')
            if os.path.exists(screenshot_filename):
                screenshot_image = pygame.image.load(screenshot_filename)
                screenshot_image = pygame.transform.scale(screenshot_image, (self.slot_width, self.slot_height))
                self.surface.blit(screenshot_image, (slot.x, slot.y))

  




    def process(self):
        mouse_pos = pygame.mouse.get_pos()
        self.sw, self.sh = self.screen.get_size()
        scale_x = self.sw / self.oss[0]
        scale_y = self.sh / self.oss[1]
        events = pygame.event.get()
        for event in events:
            if event.type == pygame.QUIT:                                   self.game.running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:                            self.game.change_state('main_menu')
                if event.key == pygame.K_F4:                                self.game.change_state('main_game')                
                if event.key == pygame.K_F11:
                    if self.fullscreen == False:
                        self.fullscreen = True
                        self.last_window_size = self.screen.get_size()
                        self.screen = pygame.display.set_mode(self.oss, pygame.FULLSCREEN)
                    elif self.fullscreen == True:
                        self.fullscreen = False
                        self.screen = pygame.display.set_mode(self.last_window_size, pygame.RESIZABLE)

            elif event.type == pygame.MOUSEBUTTONDOWN:
                scaled_mouse_pos = (mouse_pos[0] / scale_x, mouse_pos[1] / scale_y)
                for i, slot in enumerate(self.slots):
                    if slot.collidepoint(scaled_mouse_pos):
                        if event.button == 1:
                            self.game.states['main_game'].process()     # 再怎么样，这个就是跑一帧，然后回到
                            self.same_game(i+1)                            
                        elif event.button == 3:
                            loaded_dialogue = self.load_game(i+1)       # 加载游戏
                            if loaded_dialogue is not None:
                                self.game.states['main_game'].current_dialogue = loaded_dialogue
                                self.game.change_state('main_game')

        self.surface.fill((255, 255, 255))
        self.draw()
        surface = pygame.transform.scale(self.surface, (self.sw, self.sh))
        self.screen.blit(surface, (0, 0))
        pygame.display.flip()
        pygame.time.Clock().tick(144)